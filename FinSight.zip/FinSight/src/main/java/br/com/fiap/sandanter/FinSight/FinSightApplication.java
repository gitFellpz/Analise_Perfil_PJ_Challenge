package br.com.fiap.sandanter.FinSight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinSightApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinSightApplication.class, args);
	}

}
