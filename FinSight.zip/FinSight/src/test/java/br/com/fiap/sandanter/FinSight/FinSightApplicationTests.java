package br.com.fiap.sandanter.FinSight;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinSightApplicationTests {

	@Test
	void contextLoads() {
	}

}
